package model;

import java.sql.SQLException;

import framework.Model;

public class MessageModel extends Model {

	@Override
	public void create() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void save() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fetch(String o) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
	}

}
