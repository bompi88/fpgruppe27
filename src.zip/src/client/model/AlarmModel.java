package model;

public class AlarmModel {

}
