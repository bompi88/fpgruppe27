package model;

public enum StatusModel {
	ATTENDING, INVITED, DECLINED;
}
