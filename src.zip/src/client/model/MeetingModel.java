package model;

import java.sql.SQLException;

import framework.Model;

public class MeetingModel extends Model {
	
	public MeetingModel() {

	}

	@Override
	public void create() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void save() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fetch(String id) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
	}
	
	
	

}
