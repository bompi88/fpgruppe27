package framework;

public interface State {
	
	public abstract void show();
	public abstract void hide();
	
}
