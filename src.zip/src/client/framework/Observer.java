package framework;

public interface Observer {
	
	public void changeEvent(String event);

}
